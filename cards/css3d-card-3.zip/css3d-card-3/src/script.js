$('.card').on("click", function() {
  $('.container').toggleClass('container-origin')
})