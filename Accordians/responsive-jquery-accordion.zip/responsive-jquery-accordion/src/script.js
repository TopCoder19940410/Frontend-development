$(document).ready(function(){
  tabCounter = 0;
  accordionLength = $('ul#accordion li').length - 1;
  activeTab= $("#accordion li:first");

  function pageNumber(tabCounter){
    $(".page-count").html("Page " + (tabCounter+1) + " of " + (accordionLength+1));
  }
  
  function resize(direction){
    if(tabCounter != accordionLength && direction == "next"){   
        tabCounter ++;
        $(activeTab).css('width', '50px');
        $(activeTab).next().css('width', '80%');
        activeTab = $(activeTab).next();
    }else if(tabCounter > 0 && direction == "prev"){
         tabCounter--;
         $(activeTab).css('width', '50px');
         $(activeTab).prev().css('width', '80%');
         activeTab = $(activeTab).prev();
    }
  }
  
  pageNumber(tabCounter);
  
   $("#accordion #form-bar").click(function(){
     tabCounter = $( "#accordion #form-bar" ).index( this );
     $(activeTab).css('width', '50px');
     $(this).parent().css('width', '80%');
     activeTab = $(this).parent();
     pageNumber(tabCounter);
    });

 $(".next-button").click(function(){    
         resize("next");
         pageNumber(tabCounter); 
 });

 $(".prev-button").click(function(){
        resize("prev");
        pageNumber(tabCounter);
 });

       var onKeyDown = function ( event ) {
        switch ( event.keyCode ) {
          case 39:
                resize("next");
                pageNumber(tabCounter);
            break;      
          case 37:
              resize("prev");
              pageNumber(tabCounter);       
            break;
        }
      };
      document.addEventListener( 'keydown', onKeyDown, false );
});