            ///DOC READY FUNCTIONS
jQuery( document ).ready(function( $ ) {
 
	if ( jQuery( '.accordion' )[0] ){
 
		jQuery( '.accordion' ).find( '.item' ).click( function( e ){ //Click function to toggle extending lists
 
			e.preventDefault();		
 
			jQuery( this ).next().slideToggle( 'fast' ).css( 'zoom', '1' ); //Find the next element after the clicked element	
                        jQuery(".accordion > li > div").not($(this).next()).slideUp( 'fast' ).css( 'zoom', '1' );
			jQuery( this ).parent( 'li' ).toggleClass( 'collapse' ); //Add a class for styling
 
		} );
 
		jQuery( '.accordion > li' ).each( function( $ ){ //Function initially hide lists with the override class of "extended"
 
			if ( !jQuery( this ).hasClass( 'extended' ) ){
 
				jQuery( this ).find( 'div' ).slideUp( 'fast' ).css( 'zoom', '1' ); //hide all lists without a parent of "extended"
				jQuery( this ).toggleClass( 'collapse' ); //Add a class for styling
 
			}
 
		} );
 
 
	}
 
} );