
function accordion( $thisAccordion ) {

		let toggles = $thisAccordion.find('.accordion__toggle');

		const removeAllActiveClass = () => {
			toggles.each( (e) => {
				const $thisParent = $(e).parent();
				$thisParent.removeClass('active');
				$thisParent.find('.accordion__content').height(0);
			});
		};
  
		toggles.on( 'touch click', (e) => {
			e.preventDefault();

			var $thisToggle = $(e.currentTarget);
      var $thisParent = $thisToggle.parent();
      let $thisContent = $thisParent.find('.accordion__content');
      var $thisContentHeight = $thisContent.find('.accordion__content-container').outerHeight();
      
      if( !$thisParent.hasClass('active') ){
				removeAllActiveClass($thisParent);
				$thisParent.addClass('active');
				$thisContent.height($thisContentHeight);
			}else {
				$thisParent.removeClass("active");
				$thisContent.height(0);
			}
		});

		// $thisAccordion.removeClass('loading');

	}

  function initAccordion(thisAcc) { 
    thisAcc.each( function() {
      accordion( $(this) );
    }); 
  }


// init accordion after elements have loaded
	$(document).ready( () => {

		if ( $('.accordion').length > 0 ) {
			initAccordion( $('.accordion') );
		}

	});

// accordion to reset heights on window resize
$(window).resize( () => {
  
  if ( $('.accordion').length > 0 ) {
    initAccordion( $('.accordion') ); 
  }
  
});
