$('.share p').on('click', function() {

  $('.sites').slideToggle('fast', function() {});

  $('.share p').toggleClass('open');
  $('.share p:after').css('content', '-');
  $('.sites').toggleClass('shake');
});