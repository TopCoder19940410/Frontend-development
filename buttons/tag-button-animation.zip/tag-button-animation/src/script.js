jQuery(document).ready(function ($) {
	$('#wrapper').click(function() {
		$(this).toggleClass('open');
	});
});