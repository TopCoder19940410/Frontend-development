// variables
var $fb = $('.btn--fb'),
$tw = $('.btn--tw'),
$share = $('.btn--share'),
$shareImg = $('.share__image'),
$shareTitle = $('.share__title'),
$overlay = $('.overlay'), 
$ogTitle = $("meta[property='og:title']").attr('content'),
$ogImage = $("meta[property='og:image']").attr('content'),
$ogDesc = $("meta[property='og:description']").attr('content');

// TweenMax TL
var tlTW = new TimelineMax({paused: true});
var tlFB = new TimelineMax({paused: true});
var tlShare = new TimelineMax({paused: true});
var tlClose = new TimelineMax({paused: true});

tlTW.add('openTW')
.to($fb, 0.1, {autoAlpha: 0}, 'openTW')
.to($overlay, 0.3, {autoAlph: 1}, 'openTW')
.to($shareImg, 0.7, { paddingBottom: '56.25%', y: 0, autoAlpha: 1, delay: 0.6, ease: Power4.easeOut}, 'openTW')
.to($shareTitle, 0.6, {height: 'auto', autoAlpha: 1, y: 0, delay: 0.7, ease: Power4.easeOut}, 'openTW')
.to($tw, 0.6, {left: 0, width: '100%', borderRadius: 0, ease: Power4.easeInOut, onComplete: function() { $tw.addClass('can-share') }}, 'openTW')

tlFB.add('openFB')
.to($tw, 0.1, {autoAlpha: 0}, 'openFB')
.to($overlay, 0.3, {autoAlpha: 1}, 'openFB')
.to($shareImg, 0.7, { paddingBottom: '56.25%', y: 0, autoAlpha: 1, delay: 0.6, ease: Power4.easeOut }, 'openFB') 
.to($shareTitle, 0.6, {height: 'auto', autoAlpha: 1, y: 0, delay: 0.7, ease: Power4.easeOut}, 'openFB')
.to($fb, 0.6, {left: 0, width: '100%', borderRadius: 0, ease: Power4.easeInOut, onComplete: function() { $fb.addClass('can-share') }}, 'openFB')

tlShare.add('openShare')
.to($overlay, 0.3, {autoAlpha: 1}, 'openShare')
.to($fb, 0.6, {bottom: '10px', ease: Back.easeOut.config(1.5)}, 'openShare')
.to($tw, 0.8, {bottom: '10px', ease: Back.easeOut.config(1.5)}, 'openShare') 

// Share 
function openShare(e) {
  e.preventDefault(); 
  if(tlShare.progress() < 1){
    tlShare.play();
  } else {
    tlShare.restart(); 
  }
}

// Facebook share
var doFB = function (e) {
  e.preventDefault();
  if(!$(this).hasClass('can-share')) {
    if(tlFB.progress() < 1){
      tlFB.play();
    } else {
      tlFB.restart(); 
    } 
  } else {
    // share it
    $url = $(this).attr('href'); 
    $link = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent($url);
    window.open($link);
  }
}
 
// Twitter share
var doTW = function (e) {
  e.preventDefault();
  if(!$(this).hasClass('can-share')) {
    if(tlTW.progress() < 1){
      tlTW.play();
    } else {
      tlTW.restart(); 
    } 
  } else {
    // share it
    $url = $(this).attr('href'); 
    $link = 'https://twitter.com/share?url=' + encodeURIComponent($url) + '&text=' + escape($ogTitle);
    window.open($link);
  }
} 

// set to default
var setDefault = function ($el){
  TweenMax.set($fb, { clearProps: 'all'}); 
  TweenMax.set($tw, { clearProps: 'all'}); 
  TweenMax.set($shareTitle, { clearProps: 'all'}); 
  TweenMax.set($shareImg, { clearProps: 'paddingBottom', y: '0'}); 
  TweenMax.set($overlay, { clearProps: 'all'}); 
  $tw.removeClass('can-share');
  $fb.removeClass('can-share');
}

// actions
$share.on('click', openShare);
$fb.on('click', doFB); 
$tw.on('click', doTW);

// outside click
$(document).mouseup(function (e)
{ 
    var container = $(".overlay article"); 
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
      setDefault();
    }
});